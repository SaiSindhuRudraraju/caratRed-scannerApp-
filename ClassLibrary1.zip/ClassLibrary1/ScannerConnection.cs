﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    public class ScannerConnection
    {
        private AxFiScnLib.AxFiScn axFiScn1;

        public bool AutomaticSenseMedium{ get; set; }


        public void ScanDocument(int handler) 
        {
            int status;
            int ErrorCode;

            axFiScn1 = new AxFiScnLib.AxFiScn();
            axFiScn1.CreateControl();
            //Open the scanner (method)
            axFiScn1.OpenScanner2(handler); //OpenScanner2 is recommended
                                            //Start scanning images (method)
                                            //Set the scan parameters (properties)
            axFiScn1.ScanTo = 0; //Data output method: file
            axFiScn1.CompressionType = 5; //Compression format: JPEG compression
            axFiScn1.FileType = 3; //File format: JPEG file
            axFiScn1.PixelType = 2; //Pixel type: RGB color

            axFiScn1.FileName = "D:\\CaratRed\\Images####"; //File name
            axFiScn1.BarcodeDetection = true; //Barcode detection: ON
            axFiScn1.ShowSourceUI = false; //Do not display the source user interface

            status = axFiScn1.StartScan(handler);
            //An error occurred during a scan
            if (status == -1)
            {
                ErrorCode = axFiScn1.ErrorCode;
            }
            axFiScn1.CloseScanner(handler);
        }
        
    }
}
